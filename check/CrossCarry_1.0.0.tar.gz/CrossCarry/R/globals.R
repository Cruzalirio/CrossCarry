utils::globalVariables(c("Estimate_time_effect", "Per_id",
                         "Time", "lower_band", "upper_band",
                         "Y_hat", "VarY_hat", "liminf", "limsup", "Mv"))
